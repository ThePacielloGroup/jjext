// ==UserScript==
// @name        TPG Jira Jubilee
// @version     1.0.2
// @namespace   https://services.vfogroup.com/jira_jubilee
// @updateURL   https://services.vfogroup.com/jira_jubilee/tpg_jira_jubilee.meta.js
// @downloadURL https://services.vfogroup.com/jira_jubilee/tpg_jira_jubilee.user.js
// @iconURL     https://services.vfogroup.com/jira_jubilee/jjlogo.ico
// @icon64URL   https://services.vfogroup.com/jira_jubilee/jjlogo.ico
// @homepageURL https://services.vfogroup.com
// @author      Aaron Smith
// @description Provides TPG specific utilities for manipulating Jira.
// @include     https://paciellogroup.atlassian.net/*
// @grant       none
// @run-at      document-idle
// ==/UserScript==
(function() {
    'use strict';

    const myObserver = new MutationObserver(
        function (mutations) {
            mutations.forEach(function (mutation) {
                observer(mutation);
            });
        }
    );

    let lastFocus = null;

    // bindEvent - Binds an event handler to an element
    function bindEvent(element, type, handler, useCapture) {
        useCapture = (typeof useCapture === "undefined") ? false : useCapture;
        if (element.addEventListener) {
            element.addEventListener(type, handler, useCapture);
        } else {
            element.attachEvent("on" + type, handler);
        }
    }

    // observer - Callback for the MutationObserver
    function observer(mutation) {
        switch (mutation.type) {
            case 'childList':
                childListMutationHandler(mutation.addedNodes);
                break;
            case 'attributes':
                break;
            default:
                break;
        }
    }

    // childListMutationHandler - Handle the addition of nodes to the document
    function childListMutationHandler(nodes) {
        nodes.forEach(function (node) {
            switch (node.nodeType) {
                case Node.ELEMENT_NODE:
                    if (node.querySelectorAll('select[multiple]').length) {
                        modifySelects(node);
                    }
                    if (node.querySelector('div[id^="wiki-edit"].wiki-edit-toolbar')) {
                        addToolbarButtons(node);
                    }
                    break;
                default:
                    break;
            }
        });
    }

    // addCodePreviewBtn - Adds a button to a Jira issue page for previewing code snippets
    function addCodePreviewBtn() {
        //const codeNames = ['Issue Code', 'Recommended Code', /*'Remediation Guidance'*/];
        const codePanels = document.querySelectorAll('.code.panel');
        for (let i = 0; i < codePanels.length; i++) {
            const c = codePanels[i].querySelector('.codeContent.panelContent');
            if (c) {
                const previewBtn = document.createElement('button');
                previewBtn.setAttribute('class', 'aui-button');
                const previewBtnName = document.createTextNode('Preview Code');
                previewBtn.appendChild(previewBtnName);
                bindEvent(previewBtn, 'click', function(e) {
                    previewCode(e.target);
                });
                //c.parentNode.appendChild(previewBtn);
                document.body.appendChild(previewBtn);
            }
        }

        // Code preview is going to require highlight.js, so we need to add a reference to it.
        // <script src="//cdnjs.cloudflare.com/ajax/libs/highlight.js/9.12.0/highlight.min.js"></script>
        const s = document.createElement('script');
        s.setAttribute('src', '//cdnjs.cloudflare.com/ajax/libs/highlight.js/9.12.0/highlight.min.js');
        document.head.appendChild(s);

        // Also include the highlight.js styles
        // <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/highlight.js/9.12.0/styles/default.min.css">
        const l = document.createElement('link');
        l.setAttribute('rel', 'stylesheet');
        l.setAttribute('href', '//cdnjs.cloudflare.com/ajax/libs/highlight.js/9.12.0/styles/default.min.css');
        document.head.appendChild(l);

        // Plus some custom styling
        const style = document.createElement('style');
        style.type = 'text/css';
        style.innerHTML = `
          /* a11y-light theme */
          /* Based on the Tomorrow Night Eighties theme: https://github.com/isagalaev/highlight.js/blob/master/src/styles/tomorrow-night-eighties.css */
          /* @author: ericwbailey */
          /* modified by patrickhlauke: darkened "deep cerulean" #007faa to #007ea0 to allow for sufficient contrast against custom <mark> element */

          /* Comment */
          .hljs-comment,
          .hljs-quote {
            color: #696969;
          }

          /* Red */
          .hljs-variable,
          .hljs-template-variable,
          .hljs-tag,
          .hljs-name,
          .hljs-selector-id,
          .hljs-selector-class,
          .hljs-regexp,
          .hljs-deletion {
            color: #d91e18;
          }

          /* Orange */
          .hljs-number,
          .hljs-built_in,
          .hljs-builtin-name,
          .hljs-literal,
          .hljs-type,
          .hljs-params,
          .hljs-meta,
          .hljs-link {
            color: #aa5d00;
          }

          /* Yellow */
          .hljs-attribute {
            color: #aa5d00;
          }

          /* Green */
          .hljs-string,
          .hljs-symbol,
          .hljs-bullet,
          .hljs-addition {
            color: #008000;
          }

          /* Blue */
          .hljs-title,
          .hljs-section {
            color: #007ea0;
          }

          /* Purple */
          .hljs-keyword,
          .hljs-selector-tag {
            color: #7928a1;
          }

          .hljs {
            display: block;
            overflow-x: auto;
            background: #fefefe;
            color: #545454;
            padding: 0.5em;
          }

          .hljs-emphasis {
            font-style: italic;
          }

          .hljs-strong {
            font-weight: bold;
          }

          @media screen and (-ms-high-contrast: active) {
            .hljs-addition,
            .hljs-attribute,
            .hljs-built_in,
            .hljs-builtin-name,
            .hljs-bullet,
            .hljs-comment,
            .hljs-link,
            .hljs-literal,
            .hljs-meta,
            .hljs-number,
            .hljs-params,
            .hljs-string,
            .hljs-symbol,
            .hljs-type,
            .hljs-quote {
                  color: highlight;
              }

              .hljs-keyword,
              .hljs-selector-tag {
                  font-weight: bold;
              }
          }      
        `;
        document.head.appendChild(style);
    }

    // addAltVerifyBtn - Adds a button to a Jira issue page for verifying alt attributes
    function addAltVerifyBtn() {
        const descMod = document.querySelector('div#descriptionmodule');
        if (descMod) {
            const altBtn = document.createElement('button');
            altBtn.setAttribute('class', 'aui-button');
            const altBtnName = document.createTextNode('Verify Alt(s)');
            altBtn.appendChild(altBtnName);
            bindEvent(altBtn, 'click', function() {
                verifyAlts();
            });
            descMod.parentNode.insertBefore(altBtn, descMod);
        }
    }

    // verifyAlts - Verifies the alt attributes in a Jira issue page's description block
    function verifyAlts() {
        let r = '';
        const jm = document.querySelector('#descriptionmodule');
        if (jm) {
            const imgs = jm.querySelectorAll('img');
            if (imgs.length) {
                for (let i = 0; i < imgs.length; i++) {
                    const alt = imgs[i].getAttribute('alt');
                    const src = imgs[i].getAttribute('src').split('\\').pop().split('/').pop().split('?')[0];
                    if (alt === null || alt === '' || alt === src) {
                        r += src + ' missing alt (currently ' + (alt === '' ? 'empty' : alt) + ')\r\n';
                    }
                }
                if (r.length) {
                    alert(r);
                } else {
                    alert('Good to go!');
                }
            } else {
                alert('No images found!');
            }
        } else {
            alert('No description module found! Are you on an issue page?');
        }
    }

    // modifySelects - Makes select elements size match the number of their options
    function modifySelects(node) {
        const sels = node.querySelectorAll('select[multiple]');
        if (sels) {
            sels.forEach(function (sel) {
                sel.setAttribute("size", sel.length);
            });
        }
    }

    function addToolbarButtons(node) {
        const toolbarMains = node.querySelectorAll('.aui-toolbar2');
        toolbarMains.forEach(function(toolbarMain) {
            const toolbarPrimary = toolbarMain.querySelector('.aui-toolbar2-primary');
            if (toolbarPrimary) {
                addHighlightBtn(toolbarMain, toolbarPrimary);
                addStrikethroughBtn(toolbarMain, toolbarPrimary);
                addKbdBtn(toolbarMain, toolbarPrimary);
            }
        });
    }

    function addHighlightBtn(toolbarMain, toolbarPrimary) {
        const b = document.createElement('button');
        b.innerHTML = '(??)';
        b.setAttribute('class', 'aui-button');
        b.setAttribute('title', 'Highlight (??)');
        b.setAttribute('aria-label', 'Highlight');
        const btnHandler = {
            toolbarMain: toolbarMain,
            handleEvent: function(e) {
                e.preventDefault && e.preventDefault();
                // a is the textarea
                const a = toolbarMain.parentNode.nextSibling.querySelector('textarea');
                const curPos = a.selectionStart;
                const markup = '??' + a.value.slice(a.selectionStart, a.selectionEnd) + '??';
                a.value = a.value.slice(0, a.selectionStart) + markup + a.value.slice(a.selectionEnd);
                a.focus();
                a.setSelectionRange(curPos + markup.length, curPos + markup.length);
            }
        };
        bindEvent(b, 'click', btnHandler);
        toolbarPrimary.appendChild(b);
    }

    function addStrikethroughBtn(toolbarMain, toolbarPrimary) {
        const b = document.createElement('button');
        b.innerHTML = '(~~)';
        b.setAttribute('class', 'aui-button');
        b.setAttribute('title', 'Strikethrough (??)');
        b.setAttribute('aria-label', 'Strikethrough');
        const btnHandler = {
            toolbarMain: toolbarMain,
            handleEvent: function(e) {
                e.preventDefault && e.preventDefault();
                // a is the textarea
                const a = toolbarMain.parentNode.nextSibling.querySelector('textarea');
                const curPos = a.selectionStart;
                const markup = '~~' + a.value.slice(a.selectionStart, a.selectionEnd) + '~~';
                a.value = a.value.slice(0, a.selectionStart) + markup + a.value.slice(a.selectionEnd);
                a.focus();
                a.setSelectionRange(curPos + markup.length, curPos + markup.length);
            }
        };
        bindEvent(b, 'click', btnHandler);
        toolbarPrimary.appendChild(b);
    }

    function addKbdBtn(toolbarMain, toolbarPrimary) {
        const b = document.createElement('button');
        b.innerHTML = '{{Kbd}}';
        b.setAttribute('class', 'aui-button');
        b.setAttribute('title', 'Keyboard (Kbd)');
        b.setAttribute('aria-label', 'Keyboard');
        const btnHandler = {
            toolbarMain: toolbarMain,
            handleEvent: function(e) {
                e.preventDefault && e.preventDefault();
                // a is the textarea
                const a = toolbarMain.parentNode.nextSibling.querySelector('textarea');
                const curPos = a.selectionStart;
                const markup = '{{kbd:' + a.value.slice(a.selectionStart, a.selectionEnd) + '}}';
                a.value = a.value.slice(0, a.selectionStart) + markup + a.value.slice(a.selectionEnd);
                a.focus();
                a.setSelectionRange(curPos + markup.length, curPos + markup.length);
            }
        };
        bindEvent(b, 'click', btnHandler);
        toolbarPrimary.appendChild(b);
    }

    /**
     * Replaces custom formatted strings to use HTML <mark> elements
     * @param {String} text Text to convert
     * @returns {void|*|{REPLACE, REPLACE_NEGATIVE}|String|string|XML}
     */
    function highlight(text) {
        // Uses [\s\S] to capture multilines (See https://stackoverflow.com/questions/4544636/what-does-s-s-mean-in-regex-in-php/4544642#4544642)
        const regex = /\?{2}([\s\S]*?)\?{2}/gm;
        const subst = '<mark>$1</mark>';
        return text.replace(regex, subst);
    }

    /**
     * Replaces KB like strikethrough markup "~~" with HTML <del> elements
     * @param {String} text Text to convert
     * @returns {void|*|{REPLACE, REPLACE_NEGATIVE}|String|string|XML}
     */
    function strikethrough(text) {
        // Uses [\s\S] to capture multilines (See https://stackoverflow.com/questions/4544636/what-does-s-s-mean-in-regex-in-php/4544642#4544642)
        const regex = /~{2}([\s\S]*?)~{2}/gm;
        const subst = '<del>$1</del>';
        return text.replace(regex, subst);
    }

    function previewCode(target) {
        let s = target.previousSibling.querySelector("pre.code-html").textContent;
        let r = highlight(strikethrough(s));
        previewCodeDialog(r);
    }

    function previewCodeDialog(content) {
        lastFocus = document.activeElement;
        const background = document.createElement("div");
        background.setAttribute("id", "dlgCodePreviewBackground");
        background.setAttribute("tabindex", "-1");
        background.style.cssText = "position: absolute;top: 0px;left: 0px;width: 100%;height: 100%;background-color: rgba(0,0,0,.75);display: flex;align-items: center;justify-content: center;z-index: 1000;";
        document.body.appendChild(background);

        const dialog = document.createElement("div");
        dialog.setAttribute("id", "dlgCodePreviewDialog");
        dialog.setAttribute("role", "dialog");
        dialog.setAttribute("aria-labelledby", "dlgCodePreviewTitle");
        dialog.setAttribute("aria-hidden", false);
        dialog.style.cssText = "border:2px #000000 solid;border-radius:10px;background:#ffffff;display:flex;flex-direction:column;justify-content:space-between:height:12%;";
        bindEvent(dialog, "keydown", function(e) {
            e = e || event;
            switch (e.keyCode) {
                case 9: // Tab
                    var ctrls = dialog.querySelectorAll(".tabable");
                    if (e.shiftKey) {
                        if (e.target.isEqualNode(ctrls[0])) {
                            ctrls[ctrls.length - 1].focus();
                            e.preventDefault();
                        }
                    } else {
                        if (e.target.isEqualNode(ctrls[ctrls.length -1])) {
                            ctrls[0].focus();
                            e.preventDefault();
                        }
                    }
                    break;
                case 27: // Escape
                    closePreviewDlg();
                    break;
                default:
                    break;
            }
        });
        background.appendChild(dialog);

        const dialogTitle = document.createElement('h1');
        dialogTitle.innerHTML = 'Code Preview';
        dialogTitle.style.cssText = 'margin:10px;';
        dialog.appendChild(dialogTitle);

        const dialogContent = document.createElement('div');
        dialogContent.innerHTML = '<pre><code class="hljs xml">' + content + '</code></pre>';
        dialogContent.style.cssText = 'margin:10px;';
        dialog.appendChild(dialogContent);
        //hljs.highlight('html', dialogContent.innerHTML, true);
        hljs.highlightBlock(dialogContent);

        const dialogCloseBtn = document.createElement('button');
        dialogCloseBtn.setAttribute('id', 'dlgCodePreviewCloseBtn');
        dialogCloseBtn.setAttribute('class', 'aui-button tabable');
        dialogCloseBtn.innerHTML = 'Close';
        dialogCloseBtn.style.cssText = 'margin:10px;width:100px;flex:1 1 auto;align-self:flex-end;';
        bindEvent(dialogCloseBtn, 'click', function(e) {
            closePreviewDlg();
        });
        dialog.appendChild(dialogCloseBtn);

        document.body.setAttribute("aria-hidden", true);
        dialog.querySelector('#dlgCodePreviewCloseBtn').focus();
    }

    function closePreviewDlg() {
        document.body.setAttribute("aria-hidden", false);
        try {
            const bg = document.querySelector("#dlgCodePreviewBackground");
            if (bg) {
                bg.removeChild(document.querySelector("#dlgCodePreviewDialog"));
                document.body.removeChild(bg);
            }
        } catch (e) {
            console.log(e);
        }
        if (lastFocus) {
            lastFocus.focus();
        }
    }

    // main - Runs the script
    function main() {
        // Make sure we're on a Jira page.
        if (document.querySelector('meta[name="application-name"][content="JIRA"]')) {
            // In order to get selects to accept a new size, we have to hack Jira's select styling and set the height to auto, rather than a fixed size.
            const sheet = document.querySelector('link[href*="batch.css"][data-wrm-key*="jira.view.issue"]').sheet;
            if (sheet) {
                const cssRules = sheet.cssRules;
                for (let i = 0; i < cssRules.length; i++) {
                    if (cssRules[i].cssText.indexOf('.editable-field form.aui .select') > 0) {
                        if (cssRules[i].cssText.indexOf('height:') > 0) {
                            cssRules[i].style.height = 'auto';
                            break;
                        }
                    }
                }
            }
            //addCodePreviewBtn();
            addAltVerifyBtn();
            modifySelects(document);
            myObserver.observe(document.documentElement, {
                attributes: true,
                characterData: true,
                childList: true,
                subtree: true,
                attributeOldValue: true,
                characterDataOldValue: true
            });
        }
    }

    main();
})();