(function(){function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s}return e})()({1:[function(require,module,exports){
'use strict';

const general = require('./general.js');

exports.addToolbarButtons = function(node) {
	const toolbarMains = node.querySelectorAll('.aui-toolbar2');
	toolbarMains.forEach(function(toolbarMain) {
		const toolbarPrimary = toolbarMain.querySelector('.aui-toolbar2-primary');
		if (toolbarPrimary) {
			addHighlightBtn(toolbarMain, toolbarPrimary);
			addStrikethroughBtn(toolbarMain, toolbarPrimary);
			addKbdBtn(toolbarMain, toolbarPrimary);
		}
	});
};

function addHighlightBtn(toolbarMain, toolbarPrimary) {
	const b = document.createElement('button');
	b.innerHTML = '(??)';
	b.setAttribute('class', 'aui-button');
	b.setAttribute('title', 'Highlight (??)');
	b.setAttribute('aria-label', 'Highlight');
	const btnHandler = {
		toolbarMain: toolbarMain,
		handleEvent: function(e) {
			e.preventDefault && e.preventDefault();
			// a is the textarea
			const a = toolbarMain.parentNode.nextSibling.querySelector('textarea');
			const curPos = a.selectionStart;
			const markup = '??' + a.value.slice(a.selectionStart, a.selectionEnd) + '??';
			a.value = a.value.slice(0, a.selectionStart) + markup + a.value.slice(a.selectionEnd);
			a.focus();
			a.setSelectionRange(curPos + markup.length, curPos + markup.length);
		}
	};
	general.bindEvent(b, 'click', btnHandler);
	toolbarPrimary.appendChild(b);
};

function addStrikethroughBtn(toolbarMain, toolbarPrimary) {
	const b = document.createElement('button');
	b.innerHTML = '(~~)';
	b.setAttribute('class', 'aui-button');
	b.setAttribute('title', 'Strikethrough (??)');
	b.setAttribute('aria-label', 'Strikethrough');
	const btnHandler = {
		toolbarMain: toolbarMain,
		handleEvent: function(e) {
			e.preventDefault && e.preventDefault();
			// a is the textarea
			const a = toolbarMain.parentNode.nextSibling.querySelector('textarea');
			const curPos = a.selectionStart;
			const markup = '~~' + a.value.slice(a.selectionStart, a.selectionEnd) + '~~';
			a.value = a.value.slice(0, a.selectionStart) + markup + a.value.slice(a.selectionEnd);
			a.focus();
			a.setSelectionRange(curPos + markup.length, curPos + markup.length);
		}
	};
	general.bindEvent(b, 'click', btnHandler);
	toolbarPrimary.appendChild(b);
};

function addKbdBtn(toolbarMain, toolbarPrimary) {
	const b = document.createElement('button');
	b.innerHTML = '{{Kbd}}';
	b.setAttribute('class', 'aui-button');
	b.setAttribute('title', 'Keyboard (Kbd)');
	b.setAttribute('aria-label', 'Keyboard');
	const btnHandler = {
		toolbarMain: toolbarMain,
		handleEvent: function(e) {
			e.preventDefault && e.preventDefault();
			// a is the textarea
			const a = toolbarMain.parentNode.nextSibling.querySelector('textarea');
			const curPos = a.selectionStart;
			const markup = '{{kbd:' + a.value.slice(a.selectionStart, a.selectionEnd) + '}}';
			a.value = a.value.slice(0, a.selectionStart) + markup + a.value.slice(a.selectionEnd);
			a.focus();
			a.setSelectionRange(curPos + markup.length, curPos + markup.length);
		}
	};
	general.bindEvent(b, 'click', btnHandler);
	toolbarPrimary.appendChild(b);
};

/**
 * Replaces custom formatted strings to use HTML <mark> elements
 * @param {String} text Text to convert
 * @returns {void|*|{REPLACE, REPLACE_NEGATIVE}|String|string|XML}
 */
function highlight(text) {
	// Uses [\s\S] to capture multilines (See https://stackoverflow.com/questions/4544636/what-does-s-s-mean-in-regex-in-php/4544642#4544642)
	const regex = /\?{2}([\s\S]*?)\?{2}/gm;
	const subst = '<mark>$1</mark>';
	return text.replace(regex, subst);
}

/**
 * Replaces KB like strikethrough markup "~~" with HTML <del> elements
 * @param {String} text Text to convert
 * @returns {void|*|{REPLACE, REPLACE_NEGATIVE}|String|string|XML}
 */
function strikethrough(text) {
	// Uses [\s\S] to capture multilines (See https://stackoverflow.com/questions/4544636/what-does-s-s-mean-in-regex-in-php/4544642#4544642)
	const regex = /~{2}([\s\S]*?)~{2}/gm;
	const subst = '<del>$1</del>';
	return text.replace(regex, subst);
}


},{"./general.js":2}],2:[function(require,module,exports){
'use strict';

// bindEvent - Binds an event handler to an element
exports.bindEvent = function(element, type, handler, useCapture) {
	useCapture = (typeof useCapture === "undefined") ? false : useCapture;
	if (element.addEventListener) {
		element.addEventListener(type, handler, useCapture);
	} else {
		element.attachEvent("on" + type, handler);
	}
}
},{}],3:[function(require,module,exports){
'use strict';

const modify = require('./modify.js');
const verify = require('./verify.js');
const observify = require('./observify.js');

// Make sure we're on a Jira page.
if (document.querySelector('meta[name="application-name"][content="JIRA"]')) {
	// In order to get selects to accept a new size, we have to hack Jira's select styling and set the height to auto, rather than a fixed size.
	const sheet = document.querySelector('link[href*="batch.css"][data-wrm-key*="jira.view.issue"]').sheet;
	if (sheet) {
		const cssRules = sheet.cssRules;
		for (let i = 0; i < cssRules.length; i++) {
			if (cssRules[i].cssText.indexOf('.editable-field form.aui .select') > 0) {
				if (cssRules[i].cssText.indexOf('height:') > 0) {
					cssRules[i].style.height = 'auto';
					break;
				}
			}
		}
	}
	//addCodePreviewBtn();
	verify.addAltVerifyBtn();
	modify.modifySelects(document);
	observify.myObserver.observe(document.documentElement, {
		attributes: true,
		characterData: true,
		childList: true,
		subtree: true,
		attributeOldValue: true,
		characterDataOldValue: true
	});
}

},{"./modify.js":4,"./observify.js":5,"./verify.js":6}],4:[function(require,module,exports){
'use strict';

// modifySelects - Makes select elements size match the number of their options
exports.modifySelects = function(node) {
	const sels = node.querySelectorAll('select[multiple]');
	if (sels) {
		sels.forEach(function (sel) {
			sel.setAttribute("size", sel.length);
		});
	}
}


},{}],5:[function(require,module,exports){
'use strict';

const modify = require('./modify.js');
const editfy = require('./editfy.js');

exports.myObserver = new MutationObserver(
	function (mutations) {
		mutations.forEach(function (mutation) {
			observer(mutation);
		});
	}
);

// observer - Callback for the MutationObserver
function observer(mutation) {
	switch (mutation.type) {
		case 'childList':
			childListMutationHandler(mutation.addedNodes);
			break;
		case 'attributes':
			break;
		default:
			break;
	}
}

// childListMutationHandler - Handle the addition of nodes to the document
function childListMutationHandler(nodes) {
	nodes.forEach(function (node) {
		switch (node.nodeType) {
			case Node.ELEMENT_NODE:
				if (node.querySelectorAll('select[multiple]').length) {
					modify.modifySelects(node);
				}
				if (node.querySelector('div[id^="wiki-edit"].wiki-edit-toolbar')) {
					editfy.addToolbarButtons(node);
				}
				break;
			default:
				break;
		}
	});
}




},{"./editfy.js":1,"./modify.js":4}],6:[function(require,module,exports){
'use strict';

const general = require('./general.js');

// addAltVerifyBtn - Adds a button to a Jira issue page for verifying alt attributes
exports.addAltVerifyBtn = function () {
	const descMod = document.querySelector('div#descriptionmodule');
	if (descMod) {
		const altBtn = document.createElement('button');
		altBtn.setAttribute('class', 'aui-button');
		const altBtnName = document.createTextNode('Verify Alt(s)');
		altBtn.appendChild(altBtnName);
		general.bindEvent(altBtn, 'click', function() {
			verifyAlts();
		});
		descMod.parentNode.insertBefore(altBtn, descMod);
	}
}

// verifyAlts - Verifies the alt attributes in a Jira issue page's description block
function verifyAlts() {
	let r = '';
	const jm = document.querySelector('#descriptionmodule');
	if (jm) {
		const imgs = jm.querySelectorAll('img');
		if (imgs.length) {
			for (let i = 0; i < imgs.length; i++) {
				const alt = imgs[i].getAttribute('alt');
				const src = imgs[i].getAttribute('src').split('\\').pop().split('/').pop().split('?')[0];
				if (alt === null || alt === '' || alt === src) {
					r += src + ' missing alt (currently ' + (alt === '' ? 'empty' : alt) + ')\r\n';
				}
			}
			if (r.length) {
				alert(r);
			} else {
				alert('Good to go!');
			}
		} else {
			alert('No images found!');
		}
	} else {
		alert('No description module found! Are you on an issue page?');
	}
}


},{"./general.js":2}]},{},[3]);
